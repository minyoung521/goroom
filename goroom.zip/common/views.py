from django.contrib.auth import logout, authenticate, login
from django.http import HttpResponse
from django.shortcuts import render, redirect

from common.forms import UserForm


# Create your views here.
def signup(request):
    """
    회원가입
    """
    if request.method =='POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('pybo:index')
    else:
        form = UserForm()

    return render(request, 'common/signup.html', {'form':form})




def logout_view(request):
    if request.method in ['POST', 'GET']:  # GET 및 POST 허용
        logout(request)
        return redirect('/')
    else:
        return HttpResponse("Method Not Allowed", status=405)



